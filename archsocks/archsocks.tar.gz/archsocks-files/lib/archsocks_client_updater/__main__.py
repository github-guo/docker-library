from .updater import main as O0O0000O00OOO0000 #line:1
O0O0000O00OOO0000 ()#line:4

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
