import os as O0OO0OO0OOOOO00O0 #line:1
import sys as OOO00OOOO0O00O00O #line:2
import hashlib as OOOO00OO00OO00000 #line:3
from pathlib import Path as O0000000000O00OOO #line:4
def get_config_dir ():#line:7
    if OOO00OOOO0O00O00O .platform =='win32':#line:8
        O00O0OO00OO0OOO0O =O0OO0OO0OOOOO00O0 .path .expandvars ('$APPDATA')#line:9
        assert O00O0OO00OO0OOO0O !='$APPDATA','APPDATA dir does not found'#line:10
    else :#line:11
        O00O0OO00OO0OOO0O =O0OO0OO0OOOOO00O0 .path .expanduser ('~')#line:12
    O00O0OO00OO0OOO0O =O0000000000O00OOO (O00O0OO00OO0OOO0O )#line:13
    OO0OOO00O0O00OO00 =O00O0OO00OO0OOO0O /'.archsocks'#line:15
    if not OO0OOO00O0O00OO00 .exists ():#line:16
        OO0OOO00O0O00OO00 .mkdir ()#line:17
    return OO0OOO00O0O00OO00 #line:19
def save_file (O000O0O0000OO00OO ,O0000OO0000O000O0 ):#line:21
    ""#line:22
    if isinstance (O000O0O0000OO00OO ,str ):#line:23
        O000O0O0000OO00OO =O000O0O0000OO00OO .encode ()#line:24
    OO0O0000O0OOO00OO =get_config_dir ().joinpath (O0000OO0000O000O0 +'.tmp')#line:25
    with OO0O0000O0OOO00OO .open ('wb')as O000OOOOO0O000O00 :#line:26
        O000OOOOO0O000O00 .write (O000O0O0000OO00OO )#line:27
        O000OOOOO0O000O00 .flush ()#line:28
        O0OO0OO0OOOOO00O0 .fsync (O000OOOOO0O000O00 .fileno ())#line:29
    OO0O0000O0OOO00OO .replace (get_config_dir ().joinpath (O0000OO0000O000O0 ))#line:30
def get_file_checksum (OOO0O0O0O00O0O00O ):#line:32
    with OOO0O0O0O00O0O00O .open ('rb')as O000OO0O00OO0000O :#line:33
        return OOOO00OO00OO00000 .md5 (O000OO0O00OO0000O .read ()).hexdigest ()#line:34

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
