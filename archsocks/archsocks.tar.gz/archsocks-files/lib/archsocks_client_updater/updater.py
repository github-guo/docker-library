import os as O0O00000O0OOOOO00 #line:1
import sys as O0OOOOOOO0OOOOO00 #line:2
import hashlib as OOO0OO0OO0O0OO0O0 #line:3
import socket as O00OO0O0OOO00OO00 #line:4
import random as O0O0OO00O00OO0000 #line:5
import atexit as O0OOO0000O0O0O00O #line:6
import logging as O0OOOOOO0OOOOOO00 #line:7
from time import time as O000OO0O0O0O0O0O0 ,sleep as O0OO0OO0O0000O000 #line:8
from urllib .request import Request as O0O00OOO0OOOO00O0 ,urlopen as OOOO0O0000OO000OO #line:9
O0O0O0OO0O0O00OOO =__import__ ('urllib.error',globals (),locals ())#line:10
from pathlib import Path as O0OO0O00OO0OOO0OO #line:11
from subprocess import Popen as O000OO0OOO0000O00 #line:12
import zipfile as OO00OOOOO00O0OO0O #line:13
import json as O00O00O0O00O0O0O0 #line:14
from .import util as OO000OOOO0O000O00 #line:16
__all__ =['main']#line:19
OO0O0O0000OO0000O =None #line:20
OO0OOOOO000OOOOO0 =O0OOOOOO0OOOOOO00 .getLogger (__name__ )#line:21
O0O0O00O00O0OO000 =O0O00000O0OOOOO00 .environ .get ('ARCHSOCKS_ENV','production')#line:22
OO0000000000OOO00 =120 #line:23
O000O0O00OO0OOO0O =3 #line:24
O00O00OO00OO000OO =1 #line:25
def main ():#line:27
    O0OOOOOO0OOOOOO00 .basicConfig (level =getattr (O0OOOOOO0OOOOOO00 ,O0O00000O0OOOOO00 .environ .get ('ARCHSOCKS_LOG_LEVEL','INFO')),format ='[%(asctime)s][%(levelname)s]%(message)s',datefmt ='%H:%M:%S')#line:30
    O00OO0O0OO0000O0O ()#line:32
    O0OOO0000O0O0O00O .register (OO0O00O00OOOOO000 ,False )#line:33
    def O0000O0000OO00000 (OOOOO0OOO000000O0 ):#line:35
        ""#line:40
        global OO0O0O0000OO0000O #line:41
        for OOO00OO0O00000O0O in range (OOOOO0OOO000000O0 ):#line:42
            if OO0O0O0000OO0000O :#line:43
                OO0O0O0000OO0000O .poll ()#line:44
                if OO0O0O0000OO0000O .returncode is not None :#line:45
                    if OO0O0O0000OO0000O .returncode ==10 :#line:46
                        OO0OOOOO000OOOOO0 .info ('Client exited')#line:47
                        O0OOOOOOO0OOOOO00 .exit (0 )#line:48
                    else :#line:49
                        OO0OOOOO000OOOOO0 .error ('Client abnormal exited with code %d',OO0O0O0000OO0000O .returncode )#line:50
            O0OO0OO0O0000O000 (1 )#line:52
    O0OO0OO0O0000O000 (15 )#line:56
    while True :#line:58
        O000O0OOO000O000O =OOOO00OOO00OO00O0 ()#line:59
        if O000O0OOO000O000O =='new':#line:60
            OO000OOOO0O000OOO ()#line:61
        elif O000O0OOO000O000O =='error':#line:62
            O0000O0000OO00000 (900 )#line:63
            continue #line:64
        O0000O0000OO00000 (3600 )#line:65
def OOOO00OOO00OO00O0 ():#line:67
    OO000OOO00O00O00O =O0O00O000O0OOO00O ()#line:68
    OOOO0OOO0OO000O00 =O000O0O000OO0OO0O ()#line:69
    OOO00O000O0OOOOO0 =O00OO00O000O00O00 (OOOO0OOO0OO000O00 )#line:70
    for OO00O0O0O00O00O00 in OO000OOO00O00O00O :#line:71
        OO0OOOOO000OOOOO0 .info ('Checking update from %s...',OO00O0O0O00O00O00 )#line:72
        try :#line:73
            try :#line:74
                OOO00O00O000O0O0O =OOOO0O0000OO000OO (O0O00OOO0OOOO00O0 (OO00O0O0O00O00O00 ,headers ={'If-None-Match':'"{}"'.format (OOO00O000O0OOOOO0 ),'X-AS-Updater-Version':O00O00OO00OO000OO }),timeout =30 )#line:77
            except O0O0O0OO0O0O00OOO .error .HTTPError as OO00OO0OOO0O000OO :#line:78
                if OO00OO0OOO0O000OO .code ==304 :#line:79
                    OO0OOOOO000OOOOO0 .info ('No update.')#line:80
                    return 'no_update'#line:81
                else :#line:82
                    raise #line:83
            OO00O000OOOO0OOOO =OOO00O00O000O0O0O .info ().get ('ETag')#line:85
            if not OO00O000OOOO0OOOO :#line:86
                OO0OOOOO000OOOOO0 .error ('No ETag header.')#line:87
                continue #line:88
            O00OO00O00OO00OOO =OOO00O00O000O0O0O .read ()#line:90
            if OOO0OO0OO0O0OO0O0 .new ('md5',O00OO00O00OO00OOO ).hexdigest ()!=OO00O000OOOO0OOOO .strip ('"'):#line:91
                continue #line:92
            OO0OOOOO000OOOOO0 .info ('Found update.')#line:94
            OO0000O0O0000O0OO (O00OO00O00OO00OOO ,'client-new.zip')#line:95
            return 'new'#line:97
        except (OSError ,O0O0O0OO0O0O00OOO .error .HTTPError )as OO00OO0OOO0O000OO :#line:98
            OO0OOOOO000OOOOO0 .error ('Download update error: %s: %s: %s',OO00O0O0O00O00O00 ,OO00OO0OOO0O000OO .__class__ .__name__ ,OO00OO0OOO0O000OO )#line:99
        except Exception as OO00OO0OOO0O000OO :#line:100
            OO0OOOOO000OOOOO0 .error ('Download update error: %s',OO00O0O0O00O00O00 ,exc_info =True )#line:101
    OO0OOOOO000OOOOO0 .error ('Download update failed.')#line:102
    return 'error'#line:103
def O0O00O000O0OOO00O ():#line:105
    with OO00OOOOO00O0OO0O .ZipFile (str (O000O0O000OO0OO0O ()))as OO00O0OOO00O000OO :#line:106
        with OO00O0OOO00O000OO .open ('archsocks/client/serverlist.json')as OO00OO0O0O000OO00 :#line:107
            O0O00O00000OO000O =O00O00O0O00O0O0O0 .loads (OO00OO0O0O000OO00 .read ().decode ())#line:108
    O0O0OO00O00OO0000 .shuffle (O0O00O00000OO000O )#line:109
    O00O00OO00O0OOOOO =['http://{}:{}/files/client'.format (OOOO0O00OOOOOO00O ['host'],OOOO0O00OOOOOO00O ['port'])for OOOO0O00OOOOOO00O in O0O00O00000OO000O ]#line:111
    O00O00OO00O0OOOOO .append ('http://as.fxxk.ml/files/client')#line:112
    return O00O00OO00O0OOOOO #line:113
def O00OO0O0OO0000O0O (update =False ):#line:115
    global OO0O0O0000OO0000O #line:116
    OO0OOOOO000OOOOO0 .info ('Starting program...')#line:117
    OOOOO0OOO0O0OOO00 =O0O00000O0OOOOO00 .environ .copy ()#line:118
    OOOOO0OOO0O0OOO00 ['PYTHONPATH']=O0O00000O0OOOOO00 .pathsep .join ((str (OOOO000OOOO00OO0O ()/'client.zip'),str (O0OO0O00OO0OOO0OO (__file__ ).with_name ('client.zip')),OOOOO0OOO0O0OOO00 .get ('PYTHONPATH','')))#line:122
    O00OOOO000OOO0O00 =[O0OOOOOOO0OOOOO00 .executable ,'-m','archsocks.client']+O0OOOOOOO0OOOOO00 .argv [1 :]#line:123
    if update and '--do-not-open-console'not in O00OOOO000OOO0O00 :#line:124
        O00OOOO000OOO0O00 .append ('--do-not-open-console')#line:125
    OO0O0O0000OO0000O =O000OO0OOO0000O00 (O00OOOO000OOO0O00 ,env =OOOOO0OOO0O0OOO00 )#line:126
def OO0O00O00OOOOO000 (O00O00OOOO00000OO ):#line:128
    global OO0O0O0000OO0000O #line:129
    if OO0O0O0000OO0000O and OO0O0O0000OO0000O .returncode is None :#line:130
        OO0OOOOO000OOOOO0 .info ('Stopping program...')#line:131
        OO0O0O0000OO0000O .terminate ()#line:132
        if O00O00OOOO00000OO :#line:133
            OO0O0O0000OO0000O .wait ()#line:134
        OO0O0O0000OO0000O =None #line:135
def O000O0O000OO0OO0O ():#line:137
    OO0OOOO0O0OO0O00O =OOOO000OOOO00OO0O ().joinpath ('client.zip')#line:138
    if not OO0OOOO0O0OO0O00O .exists ():#line:139
        OO0OOOO0O0OO0O00O =O0OO0O00OO0OOO0OO (__file__ ).with_name ('client.zip')#line:140
        assert OO0OOOO0O0OO0O00O .exists ()#line:141
    return OO0OOOO0O0OO0O00O #line:142
def OO000OOOO0O000OOO ():#line:144
    OO0OOOOO000OOOOO0 .info ('Updating program...')#line:145
    OO0O00O00OOOOO000 (True )#line:146
    OOOO000OOOO00OO0O ().joinpath ('client-new.zip').replace (OOOO000OOOO00OO0O ().joinpath ('client.zip'))#line:147
    O00OO0O0OO0000O0O (update =True )#line:148
def OOOO000OOOO00OO0O ():#line:150
    O00O00O00O0000OO0 =O0O00000O0OOOOO00 .environ .get ('ARCHSOCKS_ENV','production')#line:151
    O00O00OOOOO0O000O =''if O00O00O00O0000OO0 =='production'else '-{}'.format (O00O00O00O0000OO0 )#line:152
    if O0OOOOOOO0OOOOO00 .platform =='win32':#line:154
        O0OO0O00O0000OO00 =O0OO0O00OO0OOO0OO (O0O00000O0OOOOO00 .path .expandvars ('$LOCALAPPDATA/archsocks'+O00O00OOOOO0O000O ))#line:155
        assert '$'not in str (O0OO0O00O0000OO00 ),'LOCALAPPDATA dir is not defined'#line:156
    else :#line:157
        O0OO0O00O0000OO00 =O0OO0O00OO0OOO0OO (O0O00000O0OOOOO00 .path .expanduser ('~/.archsocks'+O00O00OOOOO0O000O ))#line:158
    if not O0OO0O00O0000OO00 .exists ():#line:160
        O0OO0O00O0000OO00 .mkdir ()#line:161
    return O0OO0O00O0000OO00 #line:163
def OO0000O0O0000O0OO (OOOO00OOOO00OOOOO ,O00OO0OO000OOO00O ):#line:165
    ""#line:166
    if isinstance (OOOO00OOOO00OOOOO ,str ):#line:167
        OOOO00OOOO00OOOOO =OOOO00OOOO00OOOOO .encode ()#line:168
    O0OO0OOO000OOOO00 =OOOO000OOOO00OO0O ().joinpath (O00OO0OO000OOO00O +'.tmp')#line:169
    with O0OO0OOO000OOOO00 .open ('wb')as OO0000000O00O0OO0 :#line:170
        OO0000000O00O0OO0 .write (OOOO00OOOO00OOOOO )#line:171
        OO0000000O00O0OO0 .flush ()#line:172
        O0O00000O0OOOOO00 .fsync (OO0000000O00O0OO0 .fileno ())#line:173
    O0OO0OOO000OOOO00 .replace (OOOO000OOOO00OO0O ().joinpath (O00OO0OO000OOO00O ))#line:174
def O00OO00O000O00O00 (OOOO0O0OO00OOO0OO ):#line:176
    with OOOO0O0OO00OOO0OO .open ('rb')as O0OO0O0000O00O000 :#line:177
        return OOO0OO0OO0O0OO0O0 .md5 (O0OO0O0000O00O000 .read ()).hexdigest ()#line:178

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
