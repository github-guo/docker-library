import logging as O0000OO0000O0OOOO #line:1
logger =O0000OO0000O0OOOO .getLogger ('archsocks')#line:4

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
