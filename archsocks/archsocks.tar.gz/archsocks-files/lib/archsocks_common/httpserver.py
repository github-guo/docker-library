import re as OO0OO00OOOOOOOO00 #line:1
import json as O00O00000O0O0OO00 #line:2
import hashlib as OO0OOOOO000O00000 #line:3
import pkgutil as OOOOOO0O0O0000000 #line:4
import os as O00O0O000000OO0O0 #line:5
import mimetypes as O0OOO00000O0OO00O #line:6
import datetime as OO00OOOOOOO00OO0O #line:7
from functools import lru_cache as O0O00O0O0O0000O0O #line:8
import asyncio as OOO00OOOOOO0O0O0O #line:9
from collections import Counter as OO0OO0O0OO0O0O000 #line:10
import gzip as O0OO0OOOO0OOOOO00 #line:11
from urllib .parse import parse_qsl as O00O000O00OO0OO0O #line:12
import aiohttp as O0OO00OO000OOO000 #line:13
from pathlib import Path as OOO00000OOO0OOO00 #line:14
from .util import transport_closer as O0O00OO00O0O0O0OO ,co_log_exc as OO0O00O0OO0O000OO #line:16
from .log import logger as OOO000000O000OO00 #line:17
__all__ =['start','route','default_handler','abort','send','send_json','send_file','serve_static','Response','proxy','REQUEST_TIMEOUT','SERVER_NAME','DEFAULT_RESPONSE_HEADERS']#line:22
O0O000000OO0O000O =[]#line:25
REQUEST_TIMEOUT =3600 *4 #line:27
SERVER_NAME =None #line:28
DEFAULT_RESPONSE_HEADERS ={}#line:29
OOO000OO000O0000O =4096 #line:30
OO0O0OO000OO0OOO0 =0 #line:32
O000OOO0O0O00O00O =OO0OO0O0OO0O0O000 ()#line:33
def start (OOOO00OO000O00O0O ,O00O00O0OO0OO0O00 ):#line:36
    return OOO00OOOOOO0O0O0O .async (OOO00OOOOOO0O0O0O .start_server (OO00O0000OOOOO0O0 ,OOOO00OO000O00O0O ,O00O00O0OO0OO0O00 ))#line:37
@OO0O00O0OO0O000OO #line:39
@O0O00OO00O0O0O0OO #line:40
def OO00O0000OOOOO0O0 (O0O0OOO0000O000OO ,O0O00O00OOOOOO0O0 ):#line:41
    global OO0O0OO000OO0OOO0 #line:42
    OO0O0OO000OO0OOO0 +=1 #line:43
    O0OO000O0O0OO0000 =OO0O0OO000OO0OOO0 #line:44
    O0OOOOO0000O00O0O =O0O00O00OOOOOO0O0 .get_extra_info ('peername')[0 ]#line:45
    if O000OOO0O0O00O00O [O0OOOOO0000O00O0O ]>OOO000OO000O0000O :#line:46
        return #line:47
    O000OOO0O0O00O00O [O0OOOOO0000O00O0O ]+=1 #line:48
    try :#line:49
        O00O0O00000O000OO =bytearray ()#line:50
        for OO0OOOOOO00OO0O00 in range (8192 ):#line:51
            OOOO000000O0000OO =yield from OOO00OOOOOO0O0O0O .wait_for (O0O0OOO0000O000OO .read (1 ),30 )#line:52
            if not OOOO000000O0000OO :#line:53
                break #line:54
            O00O0O00000O000OO .extend (OOOO000000O0000OO )#line:55
            if O00O0O00000O000OO .endswith (b'\r\n\r\n'):#line:56
                break #line:57
        if not O00O0O00000O000OO .endswith (b'\r\n\r\n'):#line:58
            OOO000000O000OO00 .warning ('Incomplete http header: %s bytes received',len (O00O0O00000O000OO ))#line:59
            return #line:60
        OO00OOOOO0O0OOOOO ,OO00O0OO0OOOO0O00 ,O0O00OOO000OOO0O0 =O0OOO00000OOOO0OO (O00O0O00000O000OO .decode ())#line:62
        O0O0OO0OO00O0O00O =O0OO0OO000OOOOOOO (OO00OOOOO0O0OOOOO ,OO00O0OO0OOOO0O00 ,O0O00OOO000OOO0O0 ,O0O0OOO0000O000OO ,O0O00O00OOOOOO0O0 )#line:63
        OOO000000O000OO00 .info ('#%04d %s %s',O0OO000O0O0OO0000 ,O0O0OO0OO00O0O00O .method ,O0O0OO0OO00O0O00O .url )#line:64
        O00O0O0O000O0OO00 =[]#line:66
        for OO000O00OO00O0OO0 ,O00OOOO0OOO0O00OO in O0O000000OO0O000O :#line:67
            O0OOOOO0O000O0OO0 =OO000O00OO00O0OO0 .search (O0O0OO0OO00O0O00O .path )#line:68
            if O0OOOOO0O000O0OO0 :#line:69
                O00O0O0O000O0OO00 =O0OOOOO0O000O0OO0 .groups ()#line:70
                break #line:71
        else :#line:72
            O00OOOO0OOO0O00OO =default_handler #line:73
        try :#line:75
            yield from OOO00OOOOOO0O0O0O .wait_for (O00OOOO0OOO0O00OO (O0O0OO0OO00O0O00O ,*O00O0O0O000O0OO00 ),REQUEST_TIMEOUT )#line:76
        except HttpError as OOO00OO00O000OO0O :#line:77
            yield from OOO00OO00O000OO0O (O0O0OO0OO00O0O00O )#line:78
        except Exception as OOO00OO00O000OO0O :#line:79
            OOO000000O000OO00 .error ('Error handling request: %s %s',OO00OOOOO0O0OOOOO ,OO00O0OO0OOOO0O00 ,exc_info =True )#line:80
            yield from HttpError (500 )(O0O0OO0OO00O0O00O )#line:81
    finally :#line:82
        O000OOO0O0O00O00O [O0OOOOO0000O00O0O ]-=1 #line:83
        if O000OOO0O0O00O00O [O0OOOOO0000O00O0O ]==0 :#line:84
            del O000OOO0O0O00O00O [O0OOOOO0000O00O0O ]#line:85
        OOO000000O000OO00 .info ('end request %d from %s(%d)',O0OO000O0O0OO0000 ,O0OOOOO0000O00O0O ,O000OOO0O0O00O00O [O0OOOOO0000O00O0O ])#line:86
def route (O0OO0000O0OO000OO ):#line:88
    if isinstance (O0OO0000O0OO000OO ,str ):#line:89
        O0OO0000O0OO000OO =OO0OO00OOOOOOOO00 .compile ('^'+OO0OO00OOOOOOOO00 .escape (O0OO0000O0OO000OO )+'$')#line:90
    def OOO0OO0O000OOOO00 (O00000OOO0O00O000 ):#line:91
        O0O000000OO0O000O .append ((O0OO0000O0OO000OO ,O00000OOO0O00O000 ))#line:92
        return O00000OOO0O00O000 #line:93
    return OOO0OO0O000OOOO00 #line:94
@OOO00OOOOOO0O0O0O .coroutine #line:96
def default_handler (O00O0O00000000OO0 ):#line:97
    abort (404 )#line:98
class HttpError (Exception ):#line:100
    log_exception =False #line:101
    def __init__ (OO000000000O0O000 ,OO000OOO00O000000 ):#line:103
        OO000000000O0O000 .status_code =OO000OOO00O000000 #line:104
    def __call__ (OOO00OO0000OOO00O ,OO000O00OOO00OO00 ):#line:106
        yield from send (OO000O00OOO00OO00 ,OOO00OO0000OOO00O .status_code ,'text/plain',body =O0O00O0OO0OO0OO0O [OOO00OO0000OOO00O .status_code ])#line:107
def abort (*O0O00OOO00OOOOOO0 ,**O0OOOO0OOOOOO0OO0 ):#line:109
    raise HttpError (*O0O00OOO00OOOOOO0 ,**O0OOOO0OOOOOO0OO0 )#line:110
@OO0O00O0OO0O000OO #line:112
def send (O00O00OO000OO00OO ,status_code =200 ,content_type =None ,*,body =None ,**O000O00O0O0O0OO0O ):#line:113
    OOO0OOOOO0O000000 =Response (O00O00OO000OO00OO ,status_code ,content_type ,**O000O00O0O0O0OO0O )#line:114
    yield from OOO0OOOOO0O000000 .end (body )#line:115
@OO0O00O0OO0O000OO #line:117
def send_json (O0O00O0O0OO0O0O0O ,O00OOO0O0000000OO ,status_code =200 ,**O000000000OOOO0OO ):#line:118
    yield from send (O0O00O0O0OO0O0O0O ,status_code ,'application/json',body =O00O00000O0O0OO00 .dumps (O00OOO0O0000000OO ),**O000000000OOOO0OO )#line:119
@OO0O00O0OO0O000OO #line:121
def send_file (O0OOOOO0OO00O0O0O ,O00O00OOO00OO000O ,content_type =None ,force_download =False ):#line:122
    try :#line:123
        O00O0O00OO00O0000 ,OOOOO000OO00O0OOO =OO0O00OO00OOO00O0 (O00O00OOO00OO000O )#line:124
    except FileNotFoundError :#line:125
        abort (404 )#line:126
    OO000O0O00000O000 ='"%s"'%O00O0O00OO00O0000 #line:127
    if O0OOOOO0OO00O0O0O .headers .get ('if-none-match')==OO000O0O00000O000 :#line:128
        abort (304 )#line:129
    OOO00OO000O0OOO00 =OO00000O0O000OO0O (O00O00OOO00OO000O )#line:131
    if content_type is None :#line:133
        content_type =O0OOO00000O0OO00O .guess_type (OOO00OO000O0OOO00 .basename )[0 ]or 'application/octet-stream'#line:134
    OO0O0O000O0000O00 =content_type not in ('application/x-tar','application/zip','application/x-bzip')#line:139
    O00O0O00000OOO00O ={'ETag':OO000O0O00000O000 ,'Content-Length':OOOOO000OO00O0OOO }#line:141
    if force_download :#line:142
        content_type ='application/octet-stream'#line:143
        O00O0O00000OOO00O ['Content-disposition']='attachment; filename={}'.format (OOO00OO000O0OOO00 .basename )#line:144
    OO00O0O0OOOO0OO0O =Response (O0OOOOO0OO00O0O0O ,content_type =content_type ,headers =O00O0O00000OOO00O ,compress =OO0O0O000O0000O00 )#line:146
    for O0O00000000O0O00O in OOO00OO000O0OOO00 .read ():#line:147
        yield from OO00O0O0OOOO0OO0O .write (O0O00000000O0O00O )#line:148
    yield from OO00O0O0OOOO0OO0O .end ()#line:149
def serve_static (OO0OO0OO0OO0O0OO0 ,OOO00OOOO0O00O0O0 ,force_download =False ):#line:151
    @route (OO0OO00OOOOOOOO00 .compile (OO0OO0OO0OO0O0OO0 +'(.*)'))#line:152
    def O0000O0000O00OO00 (O000000O00OO0O0OO ,OOO000O000OOOO0O0 ):#line:153
        if OOO000O000OOOO0O0 .endswith ('/'):#line:154
            abort (404 )#line:155
        if not OOO000O000OOOO0O0 :#line:156
            OOO000O000OOOO0O0 ='index.html'#line:157
        if isinstance (OOO00OOOO0O00O0O0 ,tuple ):#line:159
            O0O0OOO00OOOOO0O0 ,O00O000OOOOOO00OO =OOO00OOOO0O00O0O0 #line:160
            O0O0O0OOO00OOOOOO =(O0O0OOO00OOOOO0O0 ,O00O0O000000OO0O0 .path .join (O00O000OOOOOO00OO ,OOO000O000OOOO0O0 ))#line:161
        else :#line:162
            O0O0O0OOO00OOOOOO =OOO00000OOO0OOO00 (OOO00OOOO0O00O0O0 ).joinpath (OOO000O000OOOO0O0 )#line:163
        yield from send_file (O000000O00OO0O0OO ,O0O0O0OOO00OOOOOO ,force_download =force_download )#line:164
    return O0000O0000O00OO00 #line:165
class OO00000O0O000OO0O :#line:167
    def __init__ (OO0OOO00OO0O0O0O0 ,OOOOO0O000OOO00OO ):#line:169
        OO0OOO00OO0O0O0O0 .is_pkgdata =isinstance (OOOOO0O000OOO00OO ,tuple )#line:170
        if OO0OOO00OO0O0O0O0 .is_pkgdata :#line:171
            OO0OOO00OO0O0O0O0 .package ,OO0OOO00OO0O0O0O0 .resource =OOOOO0O000OOO00OO #line:172
            OO0OOO00OO0O0O0O0 .basename =O00O0O000000OO0O0 .path .basename (OO0OOO00OO0O0O0O0 .resource )#line:173
        else :#line:174
            OO0OOO00OO0O0O0O0 .path =OOO00000OOO0OOO00 (OOOOO0O000OOO00OO )#line:175
            OO0OOO00OO0O0O0O0 .basename =O00O0O000000OO0O0 .path .basename (str (OOOOO0O000OOO00OO ))#line:176
    def read (O0OOOOOO000OO0000 ):#line:178
        if O0OOOOOO000OO0000 .is_pkgdata :#line:179
            try :#line:180
                O0O00OO00O0O000O0 =OOOOOO0O0O0000000 .get_data (O0OOOOOO000OO0000 .package ,O0OOOOOO000OO0000 .resource )#line:181
            except OSError :#line:182
                raise FileNotFoundError ()#line:183
            if O0O00OO00O0O000O0 is None :#line:184
                raise FileNotFoundError ()#line:185
            yield O0O00OO00O0O000O0 #line:186
        else :#line:187
            with O0OOOOOO000OO0000 .path .open ('rb')as O0OO0O0O000O00OOO :#line:188
                while True :#line:189
                    O0OO0O0OOOOO0OOO0 =O0OO0O0O000O00OOO .read (4096 )#line:190
                    if O0OO0O0OOOOO0OOO0 :#line:191
                        yield O0OO0O0OOOOO0OOO0 #line:192
                    else :#line:193
                        break #line:194
@O0O00O0O0O0000O0O (maxsize =1024 )#line:196
def OO0O00OO00OOO00O0 (O0OO00000O0O0OO0O ):#line:197
    OOOOO00OO0OO0O0OO =0 #line:198
    O00O0OOOO000OO00O =OO0OOOOO000O00000 .md5 ()#line:199
    for OOO0O000OO0OOO0O0 in OO00000O0O000OO0O (O0OO00000O0O0OO0O ).read ():#line:200
        O00O0OOOO000OO00O .update (OOO0O000OO0OOO0O0 )#line:201
        OOOOO00OO0OO0O0OO +=len (OOO0O000OO0OOO0O0 )#line:202
    return O00O0OOOO000OO00O .hexdigest (),OOOOO00OO0OO0O0OO #line:203
@OOO00OOOOOO0O0O0O .coroutine #line:205
def proxy (O000O00OO000O0OOO ,OOO0O0OO00O0O00O0 ,extra_headers =None ):#line:206
    O0OOO0O0OOO0O0O0O =int (O000O00OO000O0OOO .headers .get ('content-length',0 ))#line:207
    if O0OOO0O0OOO0O0O0O >0 :#line:208
        O00OO00O0OO000OO0 =yield from O000O00OO000O0OOO .client_reader .read (O0OOO0O0OOO0O0O0O )#line:209
    else :#line:210
        O00OO00O0OO000OO0 =''#line:211
    OOO0O00OO0OO00O00 =O000O00OO000O0OOO .headers .copy ()#line:213
    if extra_headers :#line:214
        OOO0O00OO0OO00O00 .update (extra_headers )#line:215
    O000O0O00OO0O000O =OOO0O0OO00O0O00O0 #line:217
    if O000O00OO000O0OOO .query_string :#line:218
        O000O0O00OO0O000O +='?'+O000O00OO000O0OOO .query_string #line:219
    OO0OO0000OOOO0O0O =yield from O0OO00OO000OOO000 .request (O000O00OO000O0OOO .method ,O000O0O00OO0O000O ,data =O00OO00O0OO000OO0 ,headers =OOO0O00OO0OO00O00 )#line:221
    OO000000OO0O00OOO =Response (O000O00OO000O0OOO ,OO0OO0000OOOO0O0O .status ,headers =OO0OO0000OOOO0O0O .headers )#line:222
    while True :#line:223
        O00OO00O0OO000OO0 =yield from OO0OO0000OOOO0O0O .content .read (4094 )#line:224
        if not O00OO00O0OO000OO0 :#line:225
            break #line:226
        yield from OO000000OO0O00OOO .write (O00OO00O0OO000OO0 )#line:227
    yield from OO000000OO0O00OOO .end ()#line:228
def O0OOO00000OOOO0OO (OO0OO000OOO0OOO00 ):#line:230
    O0O000000OOOOOO00 =OO0OO000OOO0OOO00 .split ('\r\n')#line:231
    OO0OO0OOO00O0OO00 ,OOOO00O0OO0OO0OO0 ,OOO00000OOO00OOOO =O0O000000OOOOOO00 [0 ].split ()#line:232
    OO0OO0OOO00O0OO00 =OO0OO0OOO00O0OO00 .upper ()#line:233
    O0OOOOOOO0OOOOOOO ={}#line:235
    for OO0O0O0OO00O0O000 in O0O000000OOOOOO00 [1 :]:#line:236
        if ':'in OO0O0O0OO00O0O000 :#line:237
            OO0OOOO00OO0000OO ,OO0O00O000OO00000 =OO0O0O0OO00O0O000 .split (':',1 )#line:238
            O0OOOOOOO0OOOOOOO [OO0OOOO00OO0000OO .strip ().lower ()]=OO0O00O000OO00000 .strip ()#line:239
    return OO0OO0OOO00O0OO00 ,OOOO00O0OO0OO0OO0 ,O0OOOOOOO0OOOOOOO #line:241
O0O00O0OO0OO0OO0O ={200 :'OK',304 :'Not Modified',301 :'Moved Permanently',400 :'Bad Request',401 :'Unauthorized',403 :'Forbidden',404 :'Not Found',500 :'Internal Server Error',}#line:252
OOO000O0OO000OOOO =[304 ]#line:254
class O0OO0OO000OOOOOOO :#line:256
    def __init__ (O0O000OOOO00000OO ,OOO0OOO0O000O0O0O ,O00OOOO000O0OOO0O ,OOOO0OO0OO000O000 ,O0O0000O0O0OO000O ,OOOOOO0OOO00OOO0O ):#line:258
        O0O000OOOO00000OO .method =OOO0OOO0O000O0O0O #line:259
        O0O000OOOO00000OO .url =O00OOOO000O0OOO0O #line:260
        if '?'in O00OOOO000O0OOO0O :#line:261
            O0O000OOOO00000OO .path ,O0O000OOOO00000OO .query_string =O00OOOO000O0OOO0O .split ('?',1 )#line:262
        else :#line:263
            O0O000OOOO00000OO .path ,O0O000OOOO00000OO .query_string =O00OOOO000O0OOO0O ,''#line:264
        O0O000OOOO00000OO .headers =OOOO0OO0OO000O000 #line:265
        O0O000OOOO00000OO .client_reader =O0O0000O0O0OO000O #line:267
        O0O000OOOO00000OO .client_writer =OOOOOO0OOO00OOO0O #line:268
        O0O000OOOO00000OO .query =dict (O00O000O00OO0OO0O (O0O000OOOO00000OO .query_string ))#line:269
    @OO0O00O0OO0O000OO #line:271
    def json (OO00O00O00O00OO0O ):#line:272
        if not hasattr (OO00O00O00O00OO0O ,'_json'):#line:273
            OO00OO000OOOO0O00 =yield from OOO00OOOOOO0O0O0O .wait_for (OO00O00O00O00OO0O .client_reader .read (1024 *64 ),60 )#line:274
            OO00O00O00O00OO0O ._json =O00O00000O0O0OO00 .loads (OO00OO000OOOO0O00 .decode ())#line:275
        return OO00O00O00O00OO0O ._json #line:276
class Response :#line:278
    def __init__ (O0OOO00O0O000OO0O ,OO0O000O0OOOOOOOO ,status_code =200 ,content_type =None ,*,compress =True ,headers ={}):#line:280
        O0OOO00O0O000OO0O .request =OO0O000O0OOOOOOOO #line:281
        O0OOO00O0O000OO0O .status_code =status_code #line:282
        O0OOO00O0O000OO0O .content_type =content_type #line:283
        O0OOO00O0O000OO0O .writer =OO0O000O0OOOOOOOO .client_writer #line:284
        O0OOO00O0O000OO0O .nobody =status_code in OOO000O0OO000OOOO #line:285
        O0O0000000OOOOOOO ={}#line:288
        O0O0000000OOOOOOO .update (DEFAULT_RESPONSE_HEADERS )#line:289
        O0O0000000OOOOOOO .update ({'connection':'close','date':'{:%a, %d %b %Y %H:%M:%S GMT}'.format (OO00OOOOOOO00OO0O .datetime .utcnow ()),'transfer-encoding':'chunked',})#line:294
        if O0OOO00O0O000OO0O .content_type :#line:295
            O0O0000000OOOOOOO ['content-type']=O0OOO00O0O000OO0O .content_type #line:296
        if compress and 'gzip'in OO0O000O0OOOOOOOO .headers .get ('accept-encoding','').lower ():#line:297
            O0O0000000OOOOOOO ['content-encoding']='gzip'#line:298
            O00OO0OOOO0OO000O =OOOO00OO0O0OO0O00 #line:299
        else :#line:300
            O00OO0OOOO0OO000O =OO000O0OO00000O00 #line:301
        if SERVER_NAME :#line:302
            O0O0000000OOOOOOO ['server']=SERVER_NAME #line:303
        O0O0000000OOOOOOO .update ((OO00O00O0O0O0O0O0 .lower (),O0OO0OOO0OO0OO0OO )for OO00O00O0O0O0O0O0 ,O0OO0OOO0OO0OO0OO in headers .items ())#line:304
        O000O0O0O00O0OOOO ='HTTP/1.1 {} {}\r\n'.format (status_code ,O0O00O0OO0OO0OO0O [status_code ])+'\r\n'.join ('{}: {}'.format (OOO0O0O00O00OO0OO ,O00OO000OOOOO0OOO )for OOO0O0O00O00OO0OO ,O00OO000OOOOO0OOO in O0O0000000OOOOOOO .items ())+'\r\n\r\n'#line:307
        O0OOO00O0O000OO0O .writer .write (O000O0O0O00O0OOOO .encode ())#line:308
        if not O0OOO00O0O000OO0O .nobody :#line:310
            O0OOO00O0O000OO0O ._encoder =O00OO0OOOO0OO000O ()#line:311
    @OOO00OOOOOO0O0O0O .coroutine #line:313
    def write (OOOO0O0O0OO000000 ,OO00O0OO0000OOOO0 ):#line:314
        assert not OOOO0O0O0OO000000 .nobody #line:315
        if not OO00O0OO0000OOOO0 :#line:316
            return #line:317
        OOOO0O0O0OO000000 .writer .write (OOOO0O0O0OO000000 ._encoder .write (OO00O0OO0000OOOO0 ))#line:318
        yield from OOOO0O0O0OO000000 .writer .drain ()#line:319
    @OOO00OOOOOO0O0O0O .coroutine #line:321
    def end (OO00O00OOOO00000O ,content =None ):#line:322
        if not OO00O00OOOO00000O .nobody :#line:323
            yield from OO00O00OOOO00000O .write (content )#line:324
            OO00O00OOOO00000O .writer .write (OO00O00OOOO00000O ._encoder .trailer ())#line:325
        yield from OO00O00OOOO00000O .writer .drain ()#line:326
class OO000O0OO00000O00 :#line:328
    def write (O00000O0OO0OOOO0O ,O000OOOO00OO00OO0 ):#line:330
        if not O000OOOO00OO00OO0 :#line:331
            raise ValueError ()#line:332
        if isinstance (O000OOOO00OO00OO0 ,str ):#line:333
            O000OOOO00OO00OO0 =O000OOOO00OO00OO0 .encode ()#line:334
        return _O0OOOO00OO0OOOOOO (O000OOOO00OO00OO0 )#line:335
    def trailer (OO0OO000OO0O00OO0 ):#line:337
        return b'0\r\n\r\n'#line:338
class OOOO00OO0O0OO0O00 :#line:340
    def __init__ (O00O0OO0OO000O0O0 ):#line:342
        O00O0OO0OO000O0O0 .buffer =O000OOO00O00O000O ()#line:343
        O00O0OO0OO000O0O0 .output =O0OO0OOOO0OOOOO00 .GzipFile (mode ='wb',fileobj =O00O0OO0OO000O0O0 .buffer )#line:344
    def write (OO0OO00O00OOOO000 ,OO0O000O0OOOO0000 ):#line:346
        if not OO0O000O0OOOO0000 :#line:347
            raise ValueError ()#line:348
        if isinstance (OO0O000O0OOOO0000 ,str ):#line:349
            OO0O000O0OOOO0000 =OO0O000O0OOOO0000 .encode ()#line:350
        OO0OO00O00OOOO000 .output .write (OO0O000O0OOOO0000 )#line:351
        OO0OO00O00OOOO000 .output .flush ()#line:352
        return _O0OOOO00OO0OOOOOO (OO0OO00O00OOOO000 .buffer .getvalue ())#line:353
    def trailer (O0OO0OO0OOOO0O0OO ):#line:355
        O0OO0OO0OOOO0O0OO .output .close ()#line:356
        OO00O0O00O0OO0OO0 =_O0OOOO00OO0OOOOOO (O0OO0OO0OOOO0O0OO .buffer .getvalue ())#line:357
        OO00O0O00O0OO0OO0 +=b'0\r\n\r\n'#line:358
        return OO00O0O00O0OO0OO0 #line:359
def _O0OOOO00OO0OOOOOO (OO00O0000O00O0O00 ):#line:361
    return '{:X}\r\n'.format (len (OO00O0000O00O0O00 )).encode ()+OO00O0000O00O0O00 +b'\r\n'if OO00O0000O00O0O00 else b''#line:362
class O000OOO00O00O000O :#line:364
    def __init__ (OOO0OOOOOO00OO000 ):#line:366
        OOO0OOOOOO00OO000 .buffer =bytearray ()#line:367
    def __nonzero__ (OO0000O000OOOO000 ):#line:369
        return len (OO0000O000OOOO000 .buffer )#line:370
    def write (O0000O00O000OO000 ,O0000OO000O00000O ):#line:372
        if O0000OO000O00000O :#line:373
            O0000O00O000OO000 .buffer .extend (O0000OO000O00000O )#line:374
    def flush (O0OO0OO0O0OO0O00O ):#line:376
        pass #line:377
    def getvalue (OOOOOOOOOO0O0O000 ):#line:379
        OOOOO0000000OOO0O =OOOOOOOOOO0O0O000 .buffer #line:380
        OOOOOOOOOO0O0O000 .buffer =bytearray ()#line:381
        return OOOOO0000000OOO0O #line:382
def O000O0O00O0O0O0OO ():#line:384
    OOO00OOOOOO0O0O0O .async (OOO00OOOOOO0O0O0O .start_server (OO00O0000OOOOO0O0 ,'127.0.0.1',8080 ))#line:385
    print ('serving on 127.0.0.1:8080')#line:386
    OO0O0OOOOOO0O0000 =OOO00OOOOOO0O0O0O .get_event_loop ()#line:388
    try :#line:389
        OO0O0OOOOOO0O0000 .run_forever ()#line:390
    except KeyboardInterrupt :#line:391
        OOO000000O000OO00 .info ('EXIT')#line:392
    finally :#line:393
        OO0O0OOOOOO0O0000 .close ()#line:394
if __name__ =='__main__':#line:396
    O000O0O00O0O0O0OO ()#line:397

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
