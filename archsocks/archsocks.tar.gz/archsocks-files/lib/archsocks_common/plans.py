from collections import OrderedDict as O0O0OOOO00O0OO00O #line:1
MB =1024 *1024 #line:4
GB =1024 *MB #line:5
# !!! manual sync with site_ui/index.html, controller_ui/js/User.js
plans =O0O0OOOO00O0OO00O ([('A0401',{'name':'每月4GB','price':1 ,'period_traffic':4 *GB ,'period_days':30 ,'period_name':'月','periods':1 }),('A2401',{'name':'每月24GB','price':3 ,'period_traffic':24 *GB ,'period_days':30 ,'period_name':'月','periods':1 }),('A6401',{'name':'每月64GB','price':5 ,'period_traffic':64 *GB ,'period_days':30 ,'period_name':'月','periods':1 }),])#line:18

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
