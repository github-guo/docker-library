import random as O00OOO000OOO0O0O0 #line:1
__all__ =['decode_data','encode_data']#line:2
def encode_data (OOOO000OO0OOO0000 ):#line:5
    return OOOO000OO0OOO0000 .translate (O0OOO00000OO000OO )#line:6
def decode_data (OO000OOOO0OO000O0 ):#line:8
    return OO000OOOO0OO000O0 .translate (OO0O00000O0O000OO )#line:9
def O0000O0000O000OO0 ():#line:11
    OO000OOO0OO000O00 =b'tonhdcmfybkx0123456789'#line:12
    O0O00OOO00O000OOO =b'aisrluwgpvjq9876543210'#line:13
    O0O00O0OOO0000OOO =bytes ([O00OO000OO00O0OOO for O00OO000OO00O0OOO in range (128 ,256 )])#line:14
    OOO0OO0O0OO00OOO0 =bytes (reversed (O0O00O0OOO0000OOO ))#line:15
    return bytes .maketrans (OO000OOO0OO000O00 +O0O00OOO00O000OOO +O0O00O0OOO0000OOO ,O0O00OOO00O000OOO +OO000OOO0OO000O00 +OOO0OO0O0OO00OOO0 )#line:17
O0OOO00000OO000OO =O0000O0000O000OO0 ()#line:19
OO0O00000O0O000OO =bytes .maketrans (O0OOO00000OO000OO ,bytes .maketrans (b'',b''))#line:20
if __name__ =='__main__':#line:22
    for O0OO0000O00O0000O in range (100 ):#line:23
        O00O00O0O0O0OO0O0 =[OOO00O0O000O0O0O0 for OOO00O0O000O0O0O0 in range (256 )]#line:24
        O00OOO000OOO0O0O0 .shuffle (O00O00O0O0O0OO0O0 )#line:25
        O00O00O0O0O0OO0O0 =bytes (O00O00O0O0O0OO0O0 )#line:26
        O00O0O0OO000O0000 =encode_data (O00O00O0O0O0OO0O0 )#line:28
        O000000O0OO0O00OO =decode_data (O00O0O0OO000O0000 )#line:29
        assert O00O00O0O0O0OO0O0 ==O000000O0OO0O00OO #line:30

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
