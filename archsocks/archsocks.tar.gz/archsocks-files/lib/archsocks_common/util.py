import asyncio as OOOOO0O0OO0OO00OO #line:1
import functools as OOOOOO0O0O000000O #line:2
from time import time as OO0000000OOO00O0O #line:3
from .log import logger as OOO00OO000000O0OO #line:5
def co_log_exit (O0OOO0O0000OO0000 ):#line:8
    @OOOOO0O0OO0OO00OO .coroutine #line:9
    @OOOOOO0O0O000000O .wraps (O0OOO0O0000OO0000 )#line:10
    def O0O0O0O00O00OOOOO (*OOO0OO0O00O0OOOOO ,**OO000000OOO0O0O00 ):#line:11
        try :#line:12
            return (yield from O0OOO0O0000OO0000 (*OOO0OO0O00O0OOOOO ,**OO000000OOO0O0O00 ))#line:13
        finally :#line:14
            if OOOOO0O0OO0OO00OO .get_event_loop ().is_running ():#line:15
                OOO00OO000000O0OO .critical ("coroutine '%s' abnormal exited",O0OOO0O0000OO0000 .__name__ ,exc_info =True )#line:16
    return O0O0O0O00O00OOOOO #line:17
def co_log_exc (O0OO00O0OOOO00O0O ):#line:19
    @OOOOO0O0OO0OO00OO .coroutine #line:20
    @OOOOOO0O0O000000O .wraps (O0OO00O0OOOO00O0O )#line:21
    def OO00OO00O0OOO0O00 (*O0000O0OOOOOO000O ,**OOO000OOOO0OOO00O ):#line:22
        try :#line:23
            return (yield from O0OO00O0OOOO00O0O (*O0000O0OOOOOO000O ,**OOO000OOOO0OOO00O ))#line:24
        except Exception as O00000O00O00O0OOO :#line:25
            if getattr (O00000O00O00O0OOO ,'log_exception',True ):#line:26
                OOO00OO000000O0OO .error ('%s() has thrown an exception',O0OO00O0OOOO00O0O .__name__ ,exc_info =True )#line:27
            raise #line:28
    return OO00OO00O0OOO0O00 #line:29
def transport_closer (OOO0O0OOOO0O00000 ):#line:31
    @OOOOO0O0OO0OO00OO .coroutine #line:32
    @OOOOOO0O0O000000O .wraps (OOO0O0OOOO0O00000 )#line:33
    def O0O00OO00OOO00OOO (O00000O0OO0OO0OO0 ,OO0OO00O0OO0OO0O0 ):#line:34
        try :#line:35
            return (yield from OOO0O0OOOO0O00000 (O00000O0OO0OO0OO0 ,OO0OO00O0OO0OO0O0 ))#line:36
        finally :#line:37
            OO0OO00O0OO0OO0O0 .close ()#line:38
    return O0O00OO00OOO00OOO #line:39
def expiry_cache (expiry_time =0 ,num_args =None ):#line:41
    def OOOO0OOOOOO0O0OO0 (OO0000OOO0OO0O000 ):#line:42
        if not hasattr (OO0000OOO0OO0O000 ,'_expiry_cache'):#line:43
            OO0000OOO0OO0O000 ._expiry_cache ={}#line:44
        O0OOO0O00OO0000O0 =OO0000OOO0OO0O000 ._expiry_cache #line:45
        def O00O00O0O0O00OOOO (*O0O00O0OO0OOO0OOO ,**O00OOOO00000OOOO0 ):#line:47
            O0OO0O00OOOO0OOO0 =O0O00O0OO0OOO0OOO [:num_args ]#line:48
            if O00OOOO00000OOOO0 :#line:50
                O000OOO0OOOO0OO0O =O0OO0O00OOOO0OOO0 ,frozenset (O00OOOO00000OOOO0 .iteritems ())#line:51
            else :#line:52
                O000OOO0OOOO0OO0O =O0OO0O00OOOO0OOO0 #line:53
            if O000OOO0OOOO0OO0O in O0OOO0O00OO0000O0 :#line:54
                OOOOO00000OO00O00 ,O0OOOOOOO0000O00O =O0OOO0O00OO0000O0 [O000OOO0OOOO0OO0O ]#line:55
                O00000O000O0O0OOO =OO0000000OOO00O0O ()-O0OOOOOOO0000O00O #line:57
                if not expiry_time or O00000O000O0O0OOO <expiry_time :#line:58
                    return OOOOO00000OO00O00 #line:59
            OOOOO00000OO00O00 =OO0000OOO0OO0O000 (*O0O00O0OO0OOO0OOO ,**O00OOOO00000OOOO0 )#line:60
            O0OOO0O00OO0000O0 [O000OOO0OOOO0OO0O ]=OOOOO00000OO00O00 ,OO0000000OOO00O0O ()#line:61
            return OOOOO00000OO00O00 #line:62
        return O00O00O0O0O00OOOO #line:63
    return OOOO0OOOOOO0O0OO0 #line:64

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
