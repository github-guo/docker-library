import _thread as _OO0O0O00O0O0OO0O0 #line:1
import signal as OOOOOO000OOO00O00 #line:2
def install ():#line:5
    OOOOOO000OOO00O00 .signal (OOOOOO000OOO00O00 .SIGTERM ,_OO0OO00000O0OO00O )#line:6
def _OO0OO00000O0OO00O (OO0O00O0OO0O0OOO0 ,O0O0O0OOOOOO0000O ):#line:8
    _OO0O0O00O0O0OO0O0 .interrupt_main ()#line:9

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
