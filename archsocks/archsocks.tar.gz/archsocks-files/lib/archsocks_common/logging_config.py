import os as OOO0OOO0O0O00OOOO #line:1
import sys as O00OOOOO0OOO0O0O0 #line:2
OO0O0OOO0O0O0OOO0 =__import__ ('logging.config',globals (),locals ())#line:3
def config_logging (OOO0O00O0O00OOOO0 ):#line:6
    OO0O0OOO0O0O0OOO0 .config .fileConfig (OOO0OOO0O0O00OOOO .path .join (OOO0OOO0O0O00OOOO .path .dirname (__file__ ),'logging.conf'))#line:7
    if OOO0O00O0O00OOOO0 :#line:9
        OO0O0OOO0O0O0OOO0 .getLogger ().setLevel (OO0O0OOO0O0O0OOO0 .INFO )#line:10
        OO0O0OOO0O0O0OOO0 .getLogger ('archsocks').setLevel (OO0O0OOO0O0O0OOO0 .DEBUG )#line:11

#e9015584e6a44b14988f13e2298bcbf9


#===============================================================#
# Obfuscated by Oxyry Python Obfuscator (http://pyob.oxyry.com) #
#===============================================================#
